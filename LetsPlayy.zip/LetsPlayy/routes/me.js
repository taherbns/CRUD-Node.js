const express = require('express');
const router = express.Router();

// Importez le contrôleur pour les fonctionnalités "me"
const meController = require('../controller/me.controller');
const { protect } = require('../middleware/auth');

router.route('/')
    .get(protect, meController.GetMe)  // Obtenir les informations de l'utilisateur actuel
    .put(protect, meController.UpdateMe)  // Mettre à jour les informations de l'utilisateur actuel
    .delete(protect, meController.DeleteMe);  // Supprimer l'utilisateur actuel

router.route('/resetScore')
    .put(protect, meController.UpdateMeScore);  // Réinitialiser le score de l'utilisateur actuel

module.exports = router;
