    const express = require('express');
const app = express();
const port = 5000;

// Utiliser les routes correspondantes
app.use(express.json()); 

// Importer les fichiers de routes correspondants
const routesauth = require('./routes/auths');
const routesuser = require('./routes/users');
const routesgame = require ('./routes/game');
const routesme = require('./routes/me');

// Utiliser les routes correspondantes
app.use('/auth', routesauth);
app.use('/user',routesuser);
app.use('/game',routesgame);
app.use('/me',routesme);

// Démarrer le serveur
app.listen(port , ()=> {
    console.log (`server listen on port : ${port} `);
});
