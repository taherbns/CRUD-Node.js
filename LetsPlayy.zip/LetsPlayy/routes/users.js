const express = require('express');
const router = express.Router();
const userController = require ('../controller/user.controller');

router.route('')
.get(userController.getAllUsers)
router.route('/:id')
    .put(userController.updateAsingleUser)
    .delete(userController.deleteAsingleUser)

module.exports = router;
