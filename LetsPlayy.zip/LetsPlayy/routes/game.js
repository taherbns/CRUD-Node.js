const express = require('express');
const router = express.Router();
const gameController = require('../controller/game.controller');
const authMiddleware = require('../middleware/auth');

router.put('/wins', authMiddleware.protect, gameController.wins);
router.put('/lost', authMiddleware.protect, gameController.lost);

module.exports = router;
