const users = [{
    'id' : 1 ,
    'name' : 'taher ben sedrine' , 
    'email' : 'tbns1616@gmail.com',
    'password' : '123456789',
    'points': 0,
    'isAdmin': true ,
    
}, {
    'id' : 2 ,
    'name' : 'jackop' , 
    'email' : '@jackopgmail.com',
    'password' : '12345',
    'points': 10,
    'isAdmin': false,
},{
    'id' : 3 ,
    'name' : 'jack' , 
    'email' : '@jackgmail.com',
    'password' : '12345',
    'points': 10,
    'isAdmin': false,
},{
    'id' : 4,
    'name' : 'jacky' , 
    'email' : '@jackygmail.com',
    'password' : '12345',
    'points': 10,
    'isAdmin': false,
}] ;
exports.users = users;

exports.findById = (id) => {
    for (let i = 0 ; i <users.length ;i++ ){
        const user = user[id];
        if(user.id===id){
            return user;
        }
    }
    return null ;
}

exports.findByEmail = (email) => {
for (let i = 0; i < users.length; i++) {
    const user = users[i];
    if(user.email === email){
        return user ;
    }
}
return null ;
}
//localhost:5000/auth/login
//localhost:5000/auth/register