const Users = require('../models/users');

// Fonction pour incrémenter les points d'un utilisateur (victoire)
exports.wins = (req, res) => {
    const id = req.id;

    // Recherche de l'utilisateur par ID
    const user = Users.findById(id);

    // Vérification si l'utilisateur existe
    if (!user) {
        return res.status(404).send('Utilisateur non trouvé');
    }

    // Incrémentation des points de l'utilisateur
    user.points += 1;

    // Envoi de la réponse avec les points mis à jour
    return res.status(200).json({ points: user.points });
};

// Fonction pour décrémenter les points d'un utilisateur (défaite)
exports.lost = (req, res) => {
    const id = req.id;

    // Recherche de l'utilisateur par ID
    const user = Users.findById(id);

    // Vérification si l'utilisateur existe
    if (!user) {
        return res.status(404).send('Utilisateur non trouvé');
    }

    // Vérification si l'utilisateur a suffisamment de points pour décrémenter
    if (user.points <= 0) {
        return res.status(400).send('Points insuffisants');
    }

    // Décrémentation des points de l'utilisateur
    user.points -= 1;

    // Envoi de la réponse avec les points mis à jour
    return res.status(200).json({ points: user.points });
};
