const Users = require('../models/users');
// Fonction pour obtenir les détails de l'utilisateur actuel
exports.GetMe = (req, res) => {
    const { id } = req;
    const user = Users.findById(id);
    res.status(200).send(user);
}

// Fonction pour mettre à jour les détails de l'utilisateur actuel
exports.UpdateMe = (req, res) => {
    const { userId } = req;
    const { username, email } = req.body;

    // Vérification si un autre utilisateur a déjà cet email
    const user1 = Users.findByEmail(email);
    if (user1 !== null) {
        return res.status(409).send('Conflit');
    }

    // Parcours de la liste des utilisateurs
    for (let i = 0; i < Users.length; i++) {
        const user = Users[i];
        
        // Vérification si l'ID de l'utilisateur correspond à l'ID fourni
        if (user.id === userId) {
            // Mise à jour du nom d'utilisateur et de l'email de l'utilisateur
            user.username = username;
            user.email = email;
            return res.status(200).send('Utilisateur modifié');
        }
    }
    return res.status(404).send('Not Found');
}

// Fonction pour supprimer l'utilisateur actuel
exports.DeleteMe = (req, res) => {
    const { userId } = req;
    for (let i = 0; i < Users.length; i++) {
        const user = Users[i];
        
        // Vérification si l'ID de l'utilisateur correspond à l'ID fourni
        if (user.id === userId) {
            // Suppression de l'utilisateur de la liste
            Users.splice(i, 1);
            return res.status(204).send('No Content');
        }
    }
    return res.status(404).send('Not Found');
}

// Fonction pour réinitialiser le score de l'utilisateur actuel
exports.UpdateMeScore = (req, res) => {
    const { userId } = req;

    // Parcours de la liste des utilisateurs
    for (let i = 0; i < Users.length; i++) {
        const user = Users[i];
        
        // Vérification si l'ID de l'utilisateur correspond à l'ID fourni
        if (user.id === userId) {
            // Réinitialisation du score de l'utilisateur à 0
            user.points = 0;
            return res.status(200).send('Le pointage a été remis à zéro');
        }
    }
    return res.status(404).send('Not Found');
};
