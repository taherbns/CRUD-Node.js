const jwt = require('jsonwebtoken');
const Users = require('../models/users');

exports.protect = (req, res, next) => {
    const token = req.headers.authorization;
    
    if (token === undefined || !token.startsWith('Bearer')) {
        return res.status(401).send('Unauthorized');
    }
    
    const tokenData = token.split(' ')[1];
    
    try {
        const tokendecoded = jwt.verify(tokenData, 'LetsPlay');
        req.userId = tokendecoded.id; // Stockez l'ID de l'utilisateur dans req pour un usage ultérieur
        next();
    } catch (error) {
        return res.status(401).send('Unauthorized');
    }
};

exports.isAuthorized = (req, res, next) => {
    const { id } = req.params;
    const user = Users.findById(id);
    
    if (!user) {
        return res.status(401).send('Unauthorized');
    }

    if (!user.isAdmin) {
        return res.status(401).send('Unauthorized');
    }

    next();
};
