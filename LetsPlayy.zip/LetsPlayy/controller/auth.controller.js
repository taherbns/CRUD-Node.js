const jwt = require('jsonwebtoken');
const { decode } = require('jsonwebtoken');
const User = require ('../models/users');
exports.login=(req,res)=>{
    // recuperer email et password body
    const email = req.body.email ; 
    const password = req.body.password;
    //verifier email et password ne sont pas empty 
    if(email === undefined || email.trim()==='' ){
       return  res.status(400).send('invalid email')
    };
    if(password === undefined || password=== '' ){
       return res.status(400).send('invalid password')
    };
    //trouver utulisateur avec email du body 
const user= User.findByEmail(email);
if (user === null){
    return res.status(401).send('no user found with this email');
}
    //comparer password body avec password user
    if(user.password !== password){
        return  res.status(401).send('no user found with this password');
    }
    const token = jwt.sign({'id' : user.id},'LetsPlay');    


res.status(200).send(token);
// pour le incripter res.send({'id' : user.id})
};

exports.register = (req, res) => {
    const { email, password, username } = req.body;

    // Vérification si tous les paramètres requis sont présents
    if (!email || !password || !username) {
        return res.status(400).json({ error: 'Bad Request' });
    }

    // Vérification si un utilisateur avec le même email existe déjà
    const user = User.users.find((u) => u.email === email);

    // Si l'utilisateur existe déjà, renvoyer une réponse "Conflit"
    if (user !== undefined) {
        return res.status(409).json({ error: 'Conflict' });
    }

    // Création d'un nouvel utilisateur avec les détails fournis
    const id = User.users.length + 1; // Calculez le nouvel ID
    const newUser = {
        id: id,
        email: email,
        password: password,
        username: username,
        points: 0,
        isAdmin: false,
    };

    // Ajoutez le nouvel utilisateur au tableau des utilisateurs
    User.users.push(newUser);

    // Générer un token d'authentification pour le nouvel utilisateur
    const token = jwt.sign({ id: newUser.id }, 'LetsPlay');

    // Renvoyer le token d'authentification et un statut 201 Created
    res.status(201).json({ authToken: token });
};
