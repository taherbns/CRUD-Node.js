const users = require('../models/users');
const userMid = require('../middleware/auth');
exports.getAllUsers = (req, res) => {
    const utilisateurs = [];
    
    // Parcours de la liste des utilisateurs
    for (let i = 0; i < users.users.length; i++) { 
        const user = users.users[i];
        
        // Vérification si l'utilisateur n'est pas un administrateur
        if (!user.isAdmin) {
            utilisateurs.push(user);
        }
    }
    
    // Envoi de la liste des utilisateurs
    return res.status(200).json(utilisateurs);
    
};

exports.updateAsingleUser = (req, res) => {
    const { id } = req.params;
    const { username, email } = req.body;
    
    // Vérification si un autre utilisateur a déjà cet email
    const user1 = users.users.find(user => user.email === email);
    if (user1 !== undefined) {
        return res.status(409).send('Conflit');
    }
    
    // Parcours de la liste des utilisateurs
    for (let i = 0; i < users.users.length; i++) {
        const user = users.users[i];
        
        // Vérification si l'ID de l'utilisateur correspond à l'ID fourni
        if (user.id === parseInt(id)) {
            // Mise à jour du nom d'utilisateur et de l'email de l'utilisateur
            user.username = username;
            user.email = email;
            return res.status(200).send('utulisateur modifier');
        }
    }
    
    // Si l'utilisateur n'est pas trouvé, envoi d'une réponse "Non trouvé"
    return res.status(404).send('Not found');
}

// Fonction pour supprimer un utilisateur spécifique
exports.deleteAsingleUser = (req, res) => {
    const { id } = req.params;
    
    // Parcours de la liste des utilisateurs
    for (let i = 0; i < users.users.length; i++) {
        const user = users.users[i];
        
        // Vérification si l'ID de l'utilisateur correspond à l'ID fourni
        if (user.id === parseInt(id)) {
            // Suppression de l'utilisateur de la liste
            users.users.splice(i, 1);
            return res.status(204).send('utulisateur deleted');
        }
    }
    
    // Si l'utilisateur n'est pas trouvé, envoi d'une réponse "Non trouvé"
    return res.status(404).send('Not found');
}
